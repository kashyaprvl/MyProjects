import 'package:flutter/material.dart';
import 'package:emoji_picker_flutter/emoji_picker_flutter.dart';
import 'dart:ui' as ui;

class TextToEmojiScreen extends StatefulWidget {
  const TextToEmojiScreen({super.key});

  @override
  State<TextToEmojiScreen> createState() => _TextToEmojiScreenState();
}

class _TextToEmojiScreenState extends State<TextToEmojiScreen> {

  bool emojiShowing = false;
  List<String> savetext = [];
  bool valid = false;
  String _emojiPattern = '';
  bool validate = false;
  TextEditingController _TextController = TextEditingController();
  TextEditingController _EmojiController = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomSheet:  emojiShowing ? SizedBox(
        height: 270,
        child: EmojiPicker(
            onEmojiSelected: (category, emoji) {
              setState(() {
                emojiShowing = !emojiShowing;
                _EmojiController.text = emoji.emoji;
              });
            },
            config: const Config(
              columns: 7,
              emojiSizeMax: 32,
              verticalSpacing: 0,
              horizontalSpacing: 0,
              gridPadding: EdgeInsets.zero,
              initCategory: Category.RECENT,
              bgColor: Color(0xFFF2F2F2),
              indicatorColor: Colors.blue,
              iconColor: Colors.grey,
              iconColorSelected: Colors.blue,
              backspaceColor: Colors.blue,
              skinToneDialogBgColor: Colors.white,
              skinToneIndicatorColor: Colors.grey,
              enableSkinTones: true,
              recentTabBehavior: RecentTabBehavior.RECENT,
              recentsLimit: 28,
              noRecents: Text(
                'No Recents',
                style: TextStyle(
                    fontSize: 20, color: Colors.black26),
                textAlign: TextAlign.center,
              ),
              loadingIndicator: SizedBox.shrink(),
              tabIndicatorAnimDuration: kTabScrollDuration,
              categoryIcons: CategoryIcons(),
              buttonMode: ButtonMode.MATERIAL,
            )
        ),
      ) : null,
      resizeToAvoidBottomInset: false,
      backgroundColor: Colors.white,
      appBar: AppBar(
        leading: IconButton(onPressed: (){
          Navigator.of(context).pop();
        }, icon: Image.asset("asset/images/left-chevron.png",height: 25),),
        centerTitle: true,
        title: const Text("Text To Emoji",
            style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w600,
                color: Color.fromARGB(255, 251, 246, 250,))),
        elevation: 10,
        backgroundColor: Color.fromARGB(255, 28, 96, 79),
      ),
      body: Container(
        width: double.maxFinite,
        height: double.maxFinite,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: TextFormField(
                controller: _TextController,
                decoration: InputDecoration(
                  hintText: "Enter Text",
                  errorText: validate ? "Please Fill Text" : null,
                  border: OutlineInputBorder(
                    borderSide: BorderSide(width: 1,style: BorderStyle.solid,),
                    borderRadius: BorderRadius.circular(2)
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(5.0),
              child: TextFormField(
                onChanged: (v){
                  setState(() {
                  });
                },
                controller: _EmojiController,
                readOnly: true,
                decoration: InputDecoration(
                  hintText: "Select Emoji",
                 suffixIcon: IconButton(
                   icon: Icon(Icons.clear),
                   onPressed: (){
                     _EmojiController.clear();
                   },
                 ),
                 prefixIcon: IconButton(
                   icon: Icon(Icons.emoji_emotions_outlined),
                   onPressed: (){
                     setState(() {
                       emojiShowing = !emojiShowing;
                     });
                   },
                 ),
                  border: OutlineInputBorder(
                      borderSide: BorderSide(width: 1,style: BorderStyle.solid,),
                      borderRadius: BorderRadius.circular(2)
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Container(
                height: MediaQuery.of(context).size.height * 0.5,
                width: double.maxFinite,
                decoration: BoxDecoration(
                  border: Border.all(style: BorderStyle.solid,width: 2),
                ),
                child: SingleChildScrollView(
                  child:
                Text(valid ?  _emojiPattern : '',style: TextStyle(fontSize: 10))
                ),
                ),
        ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                SizedBox(
                  height: 60,
                  width: MediaQuery.of(context).size.width * 0.5,
                  child: ElevatedButton(onPressed: (){
                    setState(() {
                      _generateEmojiPattern();
                      _TextController.text.isEmpty ? validate = true : validate = false;
                      valid = !valid;
                    });
                  }, child: Text("Generate",style: TextStyle(fontSize: 21,color: Colors.brown,fontWeight: FontWeight.w600,),)),
                ),
                SizedBox(
                  height: 60,
                  width: MediaQuery.of(context).size.width * 0.5,
                  child: ElevatedButton(onPressed: (){
                  }, child: Text("Share",style: TextStyle(fontSize: 21,color: Colors.brown,fontWeight: FontWeight.w600,),)),
                ),
              ],
             ),
    ])
      )
    );
  }

  void _generateEmojiPattern() {
    String text = _TextController.text;
    List<String> lines = [];

    for (int i = 0; i < 5; i++) {
      String line = '';
      for (int j = 0; j < 5; j++) {
        if ((i == 0 || i == 4) && (j == 0 || j == 4)) {
          line += _EmojiController.value.text;
        } else {
          line += '   ';
        }
      }
      lines.add(line);
    }

    setState(() {
      _emojiPattern = lines.join('\n');
    });
  }

}

