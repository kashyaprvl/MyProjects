import 'package:flutter/material.dart';
import 'package:image_compress/screen/home_screen.dart';
class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> with SingleTickerProviderStateMixin {
  AnimationController? _controller;
  Animation<double>? _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(seconds: 2), // Adjust duration as needed
    );
    _scaleAnimation = CurvedAnimation(
      parent: _controller!,
      curve: Curves.easeIn, // Scale up to 80%,
    );
    _controller?.forward();

    // Navigate to the next screen after animation completes
    _controller?.addListener(() {
      if (_controller!.isCompleted) {
        Navigator.pushReplacementNamed(context, '/home'); // Replace with your desired route
        // Navigator.of(context).push(_createRoute());
        // _createRoute();
      }
    });
  }


  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white, // Adjust background color as needed
      body: Center(
        child: Container(
          margin: EdgeInsets.symmetric(horizontal: 30,vertical: 15),
          padding: EdgeInsets.all(15),
          child: ScaleTransition(
            scale: _scaleAnimation!,
            child: Image.asset('assets/splashLogo.png',fit:  BoxFit.fill,height: 170,width: 170,), // Replace with your logo path
          ),
        ),
      ),
    );
  }
}
