import 'dart:io';

import 'package:dotted_border/dotted_border.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_compress/utlis/colors.dart';
import 'package:image_compress/widget/appbar.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../screen/image_compress_screen.dart';
import 'history_screen.dart';


class HomeScreen extends StatefulWidget {
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  File? _image;
  // List<String> originalImagePaths = [];
  // List<String> compressedImagePaths = [];
  // List<String> originalSizes = [];
  // List<String> compressedSizes = [];
  List<File>? selectedImages = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        showIcon: false,
        leftIconPath: "assets/svg/camera_svg.svg",
        leftOnPressed: (){
          getImage("Cemera").then((value) {
            if (value != null) {
              // if(originalImagePaths.isNotEmpty && compressedImagePaths.isNotEmpty && originalSizes.isNotEmpty && compressedSizes.isNotEmpty){
              List<File>  temp = [];
              temp.add(value);
              print("Object of temp value to store in List $temp");
              Navigator.push(context, MaterialPageRoute(builder: (context) => ImageSelectionScreen(selectedImages: temp,) ));
              // }

            }
          });
        },
        rightIconPath: "assets/svg/download_svg.svg",
        rightOnPressed: (){
          print("object");
          Navigator.push(context, MaterialPageRoute(builder: (context)=> ImageHistoryList()));
        },
      ),

      body: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Center(
            child: Image.asset('assets/splashLogo.png', fit: BoxFit.fill,
              height: 170,
              width: 170,),
          ),

          Padding(
            padding: EdgeInsets.only(top: MediaQuery
                .of(context)
                .size
                .height * 0.18, bottom: 10, left: 30, right: 30),
            child: DottedBorder(
              borderType: BorderType.RRect,
              radius: Radius.circular(20),
              dashPattern: [10, 5, 10, 5, 10, 5],
              padding: EdgeInsets.all(10),
              color: Colors.grey,

              child: Padding(
                padding: const EdgeInsets.all(15.0),
                child: Material(
                  color: Colors.transparent,
                  child: InkWell(
                    splashColor: Colors.transparent,
                    highlightColor: Colors.transparent,
                    onTap: (){
                      pickImages().then((value) {
                        if(value!.isNotEmpty && value != null){
                          Navigator.push(context, MaterialPageRoute(builder: (context) => ImageSelectionScreen(selectedImages: value,) ));

                        }
                      });
                    },
                    child: Column(
                      children: [
                        Center(
                          child: SvgPicture.asset(
                            "assets/svg/filter_logo.svg",
                            width: 45,
                            height: 45,
                            fit: BoxFit.cover,
                          ),
                        ),
                        SizedBox(height: 10,),
                        Text("Upload image", style: GoogleFonts.raleway(
                            fontWeight: FontWeight.w600, fontSize: 14))
                      ],
                    ),
                  ),
                ),
              ),
            ),
          )

        ],
      ),
    );
  }

  Future<File?> getImage(String type) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(
      source: (type == 'gallery') ? ImageSource.gallery : ImageSource.camera,
    );

    if (pickedFile != null) {
      File? croppedFile = await cropImage(pickedFile.path);
      if (croppedFile != null) {
        setState(() {
          _image = croppedFile;
        });
        print("object  On Camera  ${_image}");
        print("object  getImage On Camera  ${_image!.path}");
        return _image;
      }
    }

    return null;
  }

  Future<List<File>?> pickImages() async {

    final List<XFile> pickedFiles = await ImagePicker().pickMultiImage();
    if (pickedFiles != null) {
      setState(() {
        selectedImages = pickedFiles.map((file) => File(file.path)).toList();
      });
      print("object selecteimage lenth is ${selectedImages!.length}");
      List<File> xFileList = await convertXFilesToFiles(pickedFiles);
      return  xFileList;
    }
  }
  Future<List<File>> convertXFilesToFiles(List<XFile> xFiles) async {
    List<File> files = [];

    for (XFile xFile in xFiles) {
      // Get the path from XFile
      String path = xFile.path;

      // Create a File using the path
      File file = File(path);

      // Add the File to the list
       files.add(file);
    }

    return files;
  }



  Future<File> cropImage(String imagePath) async {
    // originalImagePaths.clear();
    // compressedImagePaths.clear();
    // originalSizes.clear();
    // compressedSizes.clear();
    CroppedFile ? croppedFile = await ImageCropper().cropImage(
      sourcePath: imagePath,


        uiSettings: [

        AndroidUiSettings(
          toolbarColor: Color.fromRGBO(4, 91, 121, 1),
          toolbarWidgetColor: Color.fromRGBO(255, 255, 255, 1),
          toolbarTitle: 'Crop Image',
          statusBarColor: Color.fromRGBO(4, 91, 121, 1),
          backgroundColor: Color.fromRGBO(4, 91, 121, 1),
          activeControlsWidgetColor: Color.fromRGBO(4, 91, 121, 1),
          // hideBottomControls: true
        ),
        IOSUiSettings(
    title: 'Cropper',
    ),
      ],
      aspectRatioPresets: [
        CropAspectRatioPreset.original,

        CropAspectRatioPreset.square,
        CropAspectRatioPreset.ratio3x2,
        CropAspectRatioPreset.ratio4x3,
        CropAspectRatioPreset.ratio16x9,
      ],
      compressFormat: ImageCompressFormat.jpg,
      compressQuality: 90,
    );


    // setState(() {
    //   originalImagePaths.add(imagePath);
    //   compressedImagePaths.add(croppedFile!.path);
    //   originalSizes.add(_formatFileSize((File(imagePath)).lengthSync()));
    //   compressedSizes.add(
    //       _formatFileSize(File(croppedFile!.path).lengthSync()));
    // });
    return File(croppedFile!.path);
  }

  String _formatFileSize(int bytes) {
    const kilobyte = 1024;
    const megabyte = 1024 * kilobyte;

    if (bytes >= megabyte) {
      return '${(bytes / megabyte).toStringAsFixed(2)} MB';
    } else if (bytes >= kilobyte) {
      return '${(bytes / kilobyte).toStringAsFixed(2)} KB';
    } else {
      return '$bytes bytes';
    }
  }
}