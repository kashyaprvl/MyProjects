import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_compress/screen/image_compreess_details_screen.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../../widget/appbar.dart';
import '../utlis/colors.dart';
import '../utlis/uiUtils.dart';
import 'history_screen.dart';

class ImageSelectionScreen extends StatefulWidget {
  List<File>? selectedImages = [];
  ImageSelectionScreen({super.key,this.selectedImages});

  @override
  _ImageSelectionScreenState createState() => _ImageSelectionScreenState();
}

class _ImageSelectionScreenState extends State<ImageSelectionScreen> {
  // List<File> _selectedImages = [];
  double _quality = 50; // Compression quality
  int _minWidth = 750;
  int _minHeight = 800;
  int totalSize = 0;



  @override
  void initState() {
    super.initState();
    calculateTotalSize();
  }

  Future<void> _pickImages() async {
    final List<XFile>? pickedFiles = await ImagePicker().pickMultiImage();
    if (pickedFiles != null) {
      setState(() {
        widget.selectedImages = pickedFiles.map((file) => File(file.path)).toList();
      });
    }
  }

  Future<void> calculateTotalSize() async {
    int calculatedSize = 0;

    for (File file in widget.selectedImages!) {
      int fileSize = await file.length();
      calculatedSize += fileSize;
    }

    setState(() {
      totalSize = calculatedSize;
    });
  }

  Future<XFile?> compressAndConvertToXFile(Uint8List imageBytes) async {
    // Compress the image (adjust parameters as needed)

    // Create a temporary file
    final tempDir = await getTemporaryDirectory();
    final tempFile = await File('${tempDir.path}/compressed_image${DateTime.now()}.jpg').writeAsBytes(imageBytes);

    // Convert the File to XFile
    XFile? file = XFile(tempFile.path);

    return file;
  }
  Future<XFile?> _compressImage(File file) async {
    final dir = await getTemporaryDirectory();
    String targetPath = dir.absolute.path + "/${DateTime.now().millisecondsSinceEpoch}.jpg";
    // final  result = await FlutterImageCompress.compressAndGetFile(
    final  result = await FlutterImageCompress.compressWithList(

      file.readAsBytesSync(), quality: _quality.toInt(),   minWidth: _minWidth,
      minHeight: _minHeight,
    );

    XFile? temp = await compressAndConvertToXFile(result)  ;
    return temp;
  }

  void _compressAllImages() async {
    List<String> originalImagePaths = [];
    List<String> compressedImagePaths = [];
    List<String> originalSizes = [];
    List<String> compressedSizes = [];

    for (var image in widget.selectedImages!) {
      var compressedImage = await _compressImage(image);

      originalImagePaths.add(image.path);
      compressedImagePaths.add(compressedImage!.path);
      originalSizes.add(_formatFileSize(image.lengthSync()));
      compressedSizes.add(_formatFileSize(File(compressedImage.path).lengthSync()));
    }

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => ImageDetailsScreen(
          originalImagePaths: originalImagePaths,
          compressedImagePaths: compressedImagePaths,
          originalSizes: originalSizes,
          compressedSizes: compressedSizes,
        ),
      ),
    );
  }

  String _formatFileSize(int bytes) {
    const kilobyte = 1024;
    const megabyte = 1024 * kilobyte;

    if (bytes >= megabyte) {
      return '${(bytes / megabyte).toStringAsFixed(2)} MB';
    } else if (bytes >= kilobyte) {
      return '${(bytes / kilobyte).toStringAsFixed(2)} KB';
    } else {
      return '$bytes bytes';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: CustomAppBar(
        showIcon: true,
        leftIconPath: "assets/svg/back_arrow_svg.svg",
        leftOnPressed: (){
          Navigator.pop(context);
        },
        rightIconPath: "assets/svg/download_svg.svg",
        rightOnPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context) => ImageHistoryList()));
        },
      ),
      body: SingleChildScrollView(
        child: Container(
                   padding: const EdgeInsets.only(top: 0.0, left: 15, right: 15),
          height: UIUtils.appHeight(context),
          child: Padding(
            padding : EdgeInsets.only(top: UIUtils.appHeight(context)  *0.02,left: 10,right: 10),
            child: Column(
              children: [
                  /// multipleimage Compress code
                if(widget.selectedImages!.length > 1)...[
                Flexible(
                  flex: 2,
                  child:

                  Column(

                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Container(
                        height: UIUtils.appHeight(context) * 0.65,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: const Color.fromRGBO(255, 255, 255, 1),
                            boxShadow:   [
                            BoxShadow(
                                color: Colors.grey.shade300,
                                spreadRadius: 0,
                                blurRadius: 1,
                              )
                            ]

                        ),
                        padding: EdgeInsets.only(left: 25,top: 5,bottom: 10,right: 25),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    // borderRadius: BorderRadius.circular(15),
                                    color: AppColor.cardBackgroungDarkColor,

                                  ),
                                  height: 40,
                                  width: 40,
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: SvgPicture.asset(
                                      "assets/svg/image_logo.svg",
                                      color: Colors.white,
                                      width: 150,
                                      height: 150,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: Text("Original Photos",style: GoogleFonts.mulish(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700
                                  ),),
                                ),


                              ],
                            ),

                           const  SizedBox(height: 10,),
                            Container(

                              height: UIUtils.appHeight(context) * 0.5,
                              child: ListView.builder(
                                scrollDirection: Axis.horizontal,
                                shrinkWrap: true,
                                itemCount: widget.selectedImages!.length ,

                                itemBuilder: (context,index) {
                                  return Container(
                                    height: UIUtils.appHeight(context) * 0.48,
                                    width: UIUtils.appWidth(context) * 0.52,
                                    margin: EdgeInsets.all(5),
                                    // decoration: BoxDecoration(
                                    //   borderRadius: BorderRadius.circular(15),
                                    //   boxShadow: [
                                    //     BoxShadow(
                                    //       color: Colors.grey.withOpacity(0.5),
                                    //       spreadRadius: 2,
                                    //       blurRadius: 5,
                                    //       offset: Offset(0, 3),
                                    //     ),
                                    //   ],
                                    // ),
                                    child: ClipRRect(
                                      // borderRadius: BorderRadius.circular(15),
                                      child: Stack(
                                        children: [
                                          Image.file(
                                            widget.selectedImages![index],
                                            fit: BoxFit.contain,
                                            width: double.infinity,
                                            height: double.infinity,
                                          ),
                                          Positioned(
                                            bottom: 0,
                                            left: 0,
                                            right: 0,
                                            child: Container(
                                              padding: EdgeInsets.all(8),
                                              decoration: BoxDecoration(
                                                gradient: LinearGradient(
                                                  begin: Alignment.bottomCenter,
                                                  end: Alignment.topCenter,
                                                  colors: [
                                                    Colors.black.withOpacity(0.7),
                                                    Colors.transparent,
                                                  ],
                                                ),
                                              ),
                                              child: Text(
                                                'Image ${index + 1}',
                                                style: TextStyle(
                                                  color: Colors.white,
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 16,
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  );

                                }
                              ),
                            ),

                            const SizedBox(height: 10,),
                            Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [

                                Text("${widget.selectedImages!.length} Images",style: GoogleFonts.mulish(
                                  textStyle: TextStyle(fontWeight:  FontWeight.w600,fontSize: 18)
                                ),),
                                Text('${ UIUtils.formatFileSize(totalSize)}',style: GoogleFonts.mulish(
                                    textStyle: TextStyle(fontWeight:  FontWeight.w600,fontSize: 16)),
                                 )



                              ],
                            ),



                          ],
                        ),
                      ),
                      SizedBox(height: 20,),
                      Container(
                        height: 150,
                        decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: Color.fromRGBO(255, 255, 255, 1),
                            boxShadow: [
                              new BoxShadow(
                                color: Colors.grey.shade300,
                                spreadRadius: 0,
                                blurRadius: 1,
                              )
                            ]

                        ),
                        // color: Colors.red,
                        padding: EdgeInsets.only(left: 25,top: 10,bottom: 10,right: 10),

                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.start,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [

                            Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    // borderRadius: BorderRadius.circular(15),
                                    color: AppColor.cardBackgroungDarkColor,

                                  ),
                                  height: 40,
                                  width: 40,
                                  child: Padding(
                                    padding: const EdgeInsets.all(8.0),
                                    child: SvgPicture.asset(
                                      "assets/svg/image_logo.svg",
                                      color: Colors.white,
                                      width: 150,
                                      height: 150,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: const EdgeInsets.only(left: 8.0),
                                  child: Text("Compress Photo",style: GoogleFonts.mulish(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700
                                  ),),
                                ),


                              ],
                            ),

                            SizedBox(height: 10,),
                            Slider(
                              value: _quality,
                              min: 0,
                              max: 100,
                              divisions: 100,
                              label: 'Quality: ${_quality.toInt()}',
                              onChanged: (double value) {
                                setState(() {


                                  _quality = value;

                                  if (_quality >= 1 && _quality <= 10) {
                                    _minWidth = 432;
                                    _minHeight = 576;
                                    print("object 10");
                                  } else if (_quality >= 11 && _quality <= 20) {
                                    _minWidth = 864;
                                    _minHeight = 1152;
                                    print("object 20");
                                  } else if (_quality >= 21 && _quality <= 30) {
                                    // Add more ranges as needed
                                    _minWidth = 1296;
                                    _minHeight = 1728;
                                    print("object 30");
                                  } else if (_quality >= 31 && _quality <= 40) {
                                    // Add more ranges as needed
                                    _minWidth = 1296;
                                    _minHeight = 1728;
                                    print("object 40");
                                  } else if (_quality >= 41 && _quality <= 50) {
                                    // Add more ranges as needed
                                    _minWidth = 1296;
                                    _minHeight = 1728;
                                    print("object 50");
                                  } else if (_quality >= 51 && _quality <= 60) {
                                    // Add more ranges as needed
                                    _minWidth = 1296;
                                    _minHeight = 1728;
                                    print("object 60");
                                  } else if (_quality >= 60 && _quality <= 70) {
                                    // Add more ranges as needed
                                    _minWidth = 1296;
                                    _minHeight = 1728;
                                    print("object  70");
                                  } else if (_quality >= 71 && _quality <= 80) {
                                    // Add more ranges as needed
                                    _minWidth = 1296;
                                    _minHeight = 1728;
                                    print("object 80");
                                  } else if (_quality >= 81 && _quality <= 90) {
                                    // Add more ranges as needed
                                    _minWidth = 1296;
                                    _minHeight = 1728;
                                    print("object 90");
                                  } else {
                                    // Default values if quality doesn't match any range
                                    _minWidth = 5184;
                                    _minHeight = 6236;
                                    print("object default");
                                  }


                                });
                              },
                              activeColor: AppColor.cardBackgroungDarkColor,
                              inactiveColor: AppColor.cardBackgroungColor,

                            ),
                          ],
                        ),
                      ),
                      SizedBox(height: 20,),
                      Padding(
                        padding: EdgeInsets.only(left: 15,right: 15),
                        child: InkWell(
                          onTap: _compressAllImages,
                          child: Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(10),
                              color: AppColor.cardBackgroungDarkColor,
                            ),
                            height: 40,
                            width: double.maxFinite,
                            child: Center(
                              child: Text("Compress Image",style: GoogleFonts.mulish(fontWeight: FontWeight.w600,fontSize: 18,color: Colors.white),),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),

                ),
                ],

                /// If Single Image That Design

                if(widget.selectedImages!.length == 1)...[
                  Flexible(
                    flex: 2,
                    child: Column(
                      mainAxisSize: MainAxisSize.min,
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Container(
                          height: UIUtils.appHeight(context) * 0.65,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(15),
                            color: Color.fromRGBO(255, 255, 255, 1),
                            boxShadow: [
                              new BoxShadow(
                                color: Colors.grey.shade300,
                                spreadRadius: 0,
                                blurRadius: 1,
                              )
                            ]

                          ),
                          padding: EdgeInsets.only(left: 25,top: 5,bottom: 10,right: 25),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      // borderRadius: BorderRadius.circular(15),
                                      color: AppColor.cardBackgroungDarkColor,

                                    ),
                                    height: 40,
                                    width: 40,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: SvgPicture.asset(
                                        "assets/svg/image_logo.svg",
                                        color: Colors.white,
                                        width: 150,
                                        height: 150,
                                        fit: BoxFit.cover,

                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 8.0),
                                    child: Text("Original Photos",style: GoogleFonts.mulish(
                                      fontSize: 16,
                                      fontWeight: FontWeight.w700
                                    ),),
                                  ),


                                ],
                              ),

                              SizedBox(height: 10,),
                              Container(
                                height: UIUtils.appHeight(context) * 0.48,
                                width: UIUtils.appWidth(context) * 0.8,
                                // width: 250,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                    image: DecorationImage(
                                      image: FileImage(widget.selectedImages!.first),
                                      fit: BoxFit.contain,
                                      alignment: Alignment.center

                                    )
                                ),
                              ),

                              SizedBox(height: 10,),
                              Padding(
                                padding: const EdgeInsets.only(left: 8.0,right: 4),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Container(
                                        width: 150,

                                        child: Text("${widget.selectedImages!.length} Images",style: GoogleFonts.mulish(fontSize: 16,fontWeight: FontWeight.w700),overflow: TextOverflow.ellipsis,maxLines: 2,)),
                                    Container(width: UIUtils.appWidth(context) * 0.23,child: Text("${_formatFileSize(widget.selectedImages!.first.lengthSync())}",style: GoogleFonts.mulish(fontSize: 16,fontWeight: FontWeight.w700),overflow: TextOverflow.ellipsis,maxLines: 2,textAlign: TextAlign.end,))
                                  ],
                                ),
                              )

                            ],
                          ),
                        ),
                        SizedBox(height: 20,),
                        Container(
                          height: 150,
                          decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(15),
                              color: Color.fromRGBO(255, 255, 255, 1),
                              boxShadow: [
                                new BoxShadow(
                                  color: Colors.grey.shade300,
                                  spreadRadius: 0,
                                  blurRadius: 1,
                                )
                              ]

                          ),
                          // color: Colors.red,
                          padding: EdgeInsets.only(left: 25,top: 10,bottom: 10,right: 10),

                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.start,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [

                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      // borderRadius: BorderRadius.circular(15),
                                      color: AppColor.cardBackgroungDarkColor,

                                    ),
                                    height: 40,
                                    width: 40,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: SvgPicture.asset(
                                        "assets/svg/image_logo.svg",
                                        color: Colors.white,
                                        width: 150,
                                        height: 150,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 8.0),
                                    child: Text("Compress Photo",style: GoogleFonts.mulish(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700
                                    ),),
                                  ),


                                ],
                              ),

                              SizedBox(height: 10,),
                              Slider(
                                value: _quality,
                                min: 0,
                                max: 100,
                                divisions: 100,
                                label: 'Quality: ${_quality.toInt()}',
                                onChanged: (double value) {
                                  setState(() {


                                    _quality = value;

                                    if (_quality >= 1 && _quality <= 10) {
                                      _minWidth = 432;
                                      _minHeight = 576;
                                      print("object 10");
                                    } else if (_quality >= 11 && _quality <= 20) {
                                      _minWidth = 864;
                                      _minHeight = 1152;
                                      print("object 20");
                                    } else if (_quality >= 21 && _quality <= 30) {
                                      // Add more ranges as needed
                                      _minWidth = 1296;
                                      _minHeight = 1728;
                                      print("object 30");
                                    } else if (_quality >= 31 && _quality <= 40) {
                                      // Add more ranges as needed
                                      _minWidth = 1296;
                                      _minHeight = 1728;
                                      print("object 40");
                                    } else if (_quality >= 41 && _quality <= 50) {
                                      // Add more ranges as needed
                                      _minWidth = 1296;
                                      _minHeight = 1728;
                                      print("object 50");
                                    } else if (_quality >= 51 && _quality <= 60) {
                                      // Add more ranges as needed
                                      _minWidth = 1296;
                                      _minHeight = 1728;
                                      print("object 60");
                                    } else if (_quality >= 60 && _quality <= 70) {
                                      // Add more ranges as needed
                                      _minWidth = 1296;
                                      _minHeight = 1728;
                                      print("object  70");
                                    } else if (_quality >= 71 && _quality <= 80) {
                                      // Add more ranges as needed
                                      _minWidth = 1296;
                                      _minHeight = 1728;
                                      print("object 80");
                                    } else if (_quality >= 81 && _quality <= 90) {
                                      // Add more ranges as needed
                                      _minWidth = 1296;
                                      _minHeight = 1728;
                                      print("object 90");
                                    } else {
                                      // Default values if quality doesn't match any range
                                      _minWidth = 5184;
                                      _minHeight = 6236;
                                      print("object default");
                                    }

                                  });
                                },
                                activeColor: AppColor.cardBackgroungDarkColor,
                                inactiveColor: AppColor.cardBackgroungColor,

                              ),
                            ],
                          ),
                        ),
                        SizedBox(height: 20,),
                        Padding(
                          padding: EdgeInsets.only(left: 15,right: 15),
                          child: InkWell(
                            onTap: _compressAllImages,
                            child: Container(
                              decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(10),
                                color: AppColor.cardBackgroungDarkColor,
                              ),
                              height: 40,
                              width: double.maxFinite,
                              child: Center(
                                child: Text("Compress Image",style: GoogleFonts.mulish(fontWeight: FontWeight.w600,fontSize: 18,color: Colors.white),),
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                ],



              ],
            ),
          ),
        ),
      ),
    );
  }
}
