import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:collection/collection.dart';
import 'dart:io';
import '../model/hivedatamodel.dart';
import '../utlis/colors.dart';
import '../utlis/uiUtils.dart';
import '../widget/appbar.dart';
import 'image_compreess_details_screen.dart'; // For groupBy

class ImageHistoryList extends StatefulWidget {
  @override
  State<ImageHistoryList> createState() => _ImageHistoryListState();
}

class _ImageHistoryListState extends State<ImageHistoryList> {
  late Future<List<ImageHistory>> _imageHistories;
  List<ImageHistory> currentSameDateData = [];

  @override
  void initState() {
    super.initState();
    _imageHistories = UIUtils.getAllImageHistories();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        showIcon: true,
        leftIconPath: "assets/svg/back_arrow_svg.svg",
        leftOnPressed: () {
          Navigator.pop(context);
        },
      ),
      body: Padding(
        padding: const EdgeInsets.all(10.0),
        child: FutureBuilder<List<ImageHistory>>(
          future: _imageHistories,
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.waiting) {
              return CircularProgressIndicator();
            } else if (snapshot.hasError) {
              return Text('Error: ${snapshot.error}');
            } else {
              List<ImageHistory>? imageHistories = snapshot.data;
              return _buildImageHistoryList(imageHistories);
            }
          },
        ),
      ),
    );
  }

  void _navigateToDetailScreen(List<ImageHistory> imageHistories) {
    List<String> compressedImagePaths = [];
    List<String> compressedSizes = [];
    List<String> originalImagePaths = [];
    List<String> originalSizes = [];
    for (int i = 0; i < imageHistories.length; i++) {
      compressedImagePaths.add(imageHistories[i].compressedPath);
      originalImagePaths.add(imageHistories[i].originalPath);
      compressedSizes.add(UIUtils.formatFileSize(File(imageHistories[i].compressedPath).lengthSync()));
      originalSizes.add(UIUtils.formatFileSize(File(imageHistories[i].originalPath).lengthSync()));
    }
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ImageDetailsScreen(
          compressedImagePaths: compressedImagePaths,
          compressedSizes: compressedSizes,
          originalImagePaths: originalImagePaths,
          originalSizes: originalSizes,
        ),
      ),
    );
  }

  Widget _buildImageHistoryList(List<ImageHistory>? imageHistories) {
    if (imageHistories!.isEmpty) {
      return Center(child: Text("NO DATA Available At that Time".toUpperCase()));
    }

    final groupedHistories = groupBy(
        imageHistories, (history) => DateFormat('dd-MM-yyyy H:mm:ss').format(history.timestamp));

    return ListView.builder(
      physics: BouncingScrollPhysics(),
      shrinkWrap: true,
           scrollDirection: Axis.vertical,
      reverse: true,
      itemCount: groupedHistories.entries.length,
      itemBuilder: (context, index) {
        var entry = groupedHistories.entries.elementAt(index);
        currentSameDateData = entry.value;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            InkWell(
              onTap: () {
                (currentSameDateData.length > 1)
                    ? _navigateToDetailScreen(currentSameDateData)
                    : null; // Pass data for selected date
              },
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
                child: (currentSameDateData.length > 1)
                    ? Text("Multiple Photos", style: GoogleFonts.mulish(fontWeight: FontWeight.w600,fontSize: 16))
                    : Text("Single Photo", style: GoogleFonts.mulish(fontWeight: FontWeight.w600,fontSize: 16)),
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              physics: BouncingScrollPhysics(),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,

                children: (currentSameDateData.length > 1)
                    ? currentSameDateData.map((history) => _buildImageHistoryItem(history, index, Colors.grey, currentSameDateData.length)).toList()
                    : currentSameDateData.map((history) => _buildImageHistoryItem(history, index, Colors.grey, 1)).toList(),
              ),
            ),
          ],
        );
      },
    );
  }

  Widget _buildImageHistoryItem(ImageHistory history, int index, Color color, int length) {
    return Padding(
      padding: const EdgeInsets.all(8.0),
      child: Container(
        height: UIUtils.appHeight(context) * 0.5,
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(15),
          color: Color.fromRGBO(255, 255, 255, 1),
          boxShadow: [
            new BoxShadow(
              color: color,
              spreadRadius: 2,
              blurRadius: 1,
            )
          ],
        ),
        padding: EdgeInsets.only(left: 25, top: 10, bottom: 10, right: 10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.start,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceAround,
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Container(
                  // color: Colors.teal,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
// borderRadius: BorderRadius.circular(15),
                          color: AppColor.cardBackgroungDarkColor,

                        ),
                        height: 35,
                        width: 35,
                        child: Padding(
                          padding: const EdgeInsets.all(8.0),
                          child: SvgPicture.asset(
                            "assets/svg/image_logo.svg",
                            color: Colors.white,
                            width: 150,
                            height: 150,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                      Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text("Compress Photo",style: GoogleFonts.mulish(
                                fontSize: 12,
                                fontWeight: FontWeight.w700
                            ),),
                            Text("${UIUtils.appDateTimeFormat(history.timestamp)}",style: GoogleFonts.mulish(
                                fontSize: 12,
                                fontWeight: FontWeight.w700,
                                color: AppColor.cardBackgroungDarkColor
                            ),),
                          ],
                        ),
                      ),

                    ],
                  ),
                ),
                Container(
                  width: UIUtils.appWidth(context) * 0.3,
                  // color: Colors.grey,
                  child: Row(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    mainAxisAlignment: MainAxisAlignment.end,
                    children: [

                      InkWell(
                        onTap: (){
                          Fluttertoast.showToast(msg: "Download Start ...",);
                          List<String> temp = [];
                          temp.add(history.compressedPath);
                          UIUtils.appImageSaveDownload(temp);
                        },
                        child: Container(
                          height: 35,
                          width: 35,
                          decoration: BoxDecoration(
                            color: AppColor.cardBackgroungLightColor,
                            shape: BoxShape.circle,
                          ),
                          child: Icon(Icons.downloading_sharp),
                        ),
                      ),
                      SizedBox(width: 10,),
                      InkWell(
                        onTap: (){
                          UIUtils.deleteImageHistory(index).then((value) {
                            // UIUtils.getAllImageHistories();
                            setState(() {
                              _imageHistories = UIUtils.getAllImageHistories();
                            });
                            Fluttertoast.showToast(msg: "Delete Successfully..");

                          });
                        },
                        child: Container(
                          height: 35,
                          width: 35,
                          padding: EdgeInsets.all(5),
                          decoration: BoxDecoration(
                            color: AppColor.appRedColor,
                            shape: BoxShape.circle,
                          ),
                          child:  SvgPicture.asset(
                            "assets/svg/delete.svg",
                            width: 30,
                            height: 30,
                            fit: BoxFit.cover,
                          ),
                        ),
                      ),
                    ],
                  ),
                )

              ],
            ),

            SizedBox(height: 15,),

            Row(
              children: [
                InkWell(
                  splashColor: Colors.transparent,
                  onTap: () {
                    if (length > 1) {
                      // Pass a list of image paths if there are multiple images
                      UIUtils.showImagePopup(context, currentSameDateData.map((history) => history.originalPath).toList(), "Details: Add your details here");
                    } else {
                      // Pass a single image path if there is only one image
                      UIUtils.showImagePopup(context, history.originalPath, "Details: Add your details here");
                    }
                    // UIUtils.showImagePopup(context, currentSameDateData.map((history) => history.originalPath).toList(), "Details: Add your details here");
                  },
                  child: Container(
                    height: UIUtils.appHeight(context) * 0.32,
                    width: UIUtils.appWidth(context) * 0.37,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      image: DecorationImage(
                        image: FileImage(File(history.originalPath)),
                        fit: BoxFit.fitHeight,
                      ),
                    ),
                  ),
                ),
                SizedBox(width: 15),
                InkWell(
                  splashColor: Colors.teal,
                  onTap: () {
                    if (length > 1) {
                      // Pass a list of image paths if there are multiple images
                      UIUtils.showImagePopup(context, currentSameDateData.map((history) => history.compressedPath).toList(), "Details: Add your details here");
                    } else {
                      // Pass a single image path if there is only one image
                      UIUtils.showImagePopup(context, history.compressedPath, "Details: Add your details here");
                    }
                    // UIUtils.showImagePopup(context, currentSameDateData.map((history) => history.compressedPath).toList(), "Details: Add your details here");
                  },
                  child: Container(
                    height: UIUtils.appHeight(context) * 0.32,
                    width: UIUtils.appWidth(context) * 0.37,
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(15),
                      image: DecorationImage(
                        image: FileImage(File(history.compressedPath)),
                        fit: BoxFit.fitHeight,
                        alignment: Alignment.center,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            Row(
              children: [
                Container(
                  height: 50,
                  width: UIUtils.appWidth(context) * 0.37,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Before",style: GoogleFonts.mulish(fontWeight: FontWeight.w500,fontSize: 16),),
                      Text("${UIUtils.formatFileSize(File(history.originalPath).lengthSync())}",style: GoogleFonts.mulish(fontWeight: FontWeight.w500,fontSize: 16,color: Color.fromRGBO(161, 161, 161, 1)),)
                    ],
                  ),
                ),

                SizedBox(width: 15,),

                Container(
                  height: 50,
                  width: UIUtils.appWidth(context) * 0.37,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("After",style: GoogleFonts.mulish(fontWeight: FontWeight.w500,fontSize: 16),),
                      Text("${UIUtils.formatFileSize(File(history.compressedPath).lengthSync())}",style: GoogleFonts.mulish(fontWeight: FontWeight.w500,fontSize: 16,color: Color.fromRGBO(161, 161, 161, 1)),)
                    ],
                  ),
                ),

              ],
            )
          ],
        ),
      ),
    );
  }
}
