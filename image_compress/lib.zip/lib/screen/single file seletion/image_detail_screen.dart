import 'package:flutter/cupertino.dart';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:gallery_saver/gallery_saver.dart';
import 'package:path_provider/path_provider.dart';

import '../../utlis/colors.dart';
class ImageDetailsScreen extends StatelessWidget {
  final String originalImagePath;
  final String compressedImagePath;
  final String originalSize;
  final String compressedSize;

  ImageDetailsScreen({
    required this.originalImagePath,
    required this.compressedImagePath,
    required this.originalSize,
    required this.compressedSize,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Image Details"),
      ),
      body: Padding(
        padding: EdgeInsets.all(10),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              height: 250,
              decoration: BoxDecoration(
                  border: Border.all(width: 1, color: AppColor.appThemeColors,),
                  borderRadius: BorderRadius.all(Radius.circular(50)),
                  image: DecorationImage(
                      image: FileImage(File(originalImagePath)),
                      fit: BoxFit.contain
                  )
              ),
              // child: Image.file(widget.imageFile!, height: 200, width: 200)
            ),
            // Image.file(File(originalImagePath), height: 200, width: 200),
            SizedBox(height: 10),
            Text(originalSize),
            SizedBox(height: 10),
            if (compressedImagePath.isNotEmpty)
              Column(
                children: [

                  Container(
                    height: 250,
                    padding: const EdgeInsets.all(6.0),
                    decoration: BoxDecoration(
                        border: Border.all(width: 1, color: AppColor.appThemeColors,),
                        borderRadius: BorderRadius.all(Radius.circular(50)),
                        image: DecorationImage(
                            image: FileImage(File(compressedImagePath)),
                            fit: BoxFit.contain
                        )
                    ),
                    // child: Image.file(widget.imageFile!, height: 200, width: 200)
                  ),
                  // Image.file(File(compressedImagePath), height: 200, width: 200),
                  SizedBox(height: 10),
                  Text(compressedSize),
                  SizedBox(height: 10),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColor.appBarColors
                    ),
                    onPressed: () async {
                      final directory = await getDownloadsDirectory();
                      final downloadPath = directory!.path;
                      final fileName =
                          'CompressedImage_${DateTime.now().millisecondsSinceEpoch}.jpg';

                      final newFilePath = '$downloadPath/$fileName';

                      File(compressedImagePath).copySync(newFilePath);
                      await GallerySaver.saveImage(compressedImagePath, albumName: "ImageCompresser");

                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Image downloaded to $newFilePath'),
                        ),
                      );
                    },
                    child: Text('Download Compressed Image'),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
