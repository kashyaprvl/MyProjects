import 'dart:typed_data';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:gallery_saver/gallery_saver.dart';
import 'package:image_compress/utlis/colors.dart';
import 'dart:io';
import 'package:image_cropper/image_cropper.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import '../../screen/single file seletion/image_detail_screen.dart';

import '../../utlis/uiUtils.dart';
import 'image_detail_screen.dart';

class ConversionHistory {
  String originalImagePath;
  String compressedImagePath;
  String originalSize;
  String compressedSize;

  ConversionHistory({
    required this.originalImagePath,
    required this.compressedImagePath,
    required this.originalSize,
    required this.compressedSize,
  });
}

class ImageProcessingScreen extends StatefulWidget {
  File? imageFile;

  ImageProcessingScreen({this.imageFile});

  @override
  State<ImageProcessingScreen> createState() => _ImageProcessingScreenState();
}

class _ImageProcessingScreenState extends State<ImageProcessingScreen> {
  CroppedFile? croppedFile;
  File? _compressedImage;
  String _originalSize = '';
  String _compressedSize = '';
  int _minWidth = 750;
  int _minHeight = 800;
  int _quality = 85;

  List<ConversionHistory> _conversionHistory = [];


  @override
  void initState() {
    super.initState();
  }

  Future<void> _cropImage(BuildContext context) async {
    croppedFile = await ImageCropper().cropImage(
      sourcePath: widget.imageFile!.path,
      aspectRatioPresets: [
        CropAspectRatioPreset.square,
        CropAspectRatioPreset.ratio3x2,
        CropAspectRatioPreset.ratio4x3,
        CropAspectRatioPreset.ratio16x9,
      ],
      compressFormat: ImageCompressFormat.jpg,
      compressQuality: 90,
    );

    if (croppedFile != null) {
      File temp = File(croppedFile!.path.toString());

      Navigator.of(context).pushReplacement(MaterialPageRoute(
        builder: (context) => ImageProcessingScreen(imageFile: temp),
      ));
    }
  }


  Future<void> _compressImage() async {
    try{
      if (widget.imageFile == null) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Please select an image before compressing.'),
          ),
        );
        return;
      }

      int originalSize = await widget.imageFile!.length();

      print("object ninlkd  Qulity $_quality");
      List<int> imageBytes = await FlutterImageCompress.compressWithList(
        widget.imageFile!.readAsBytesSync(),
        minWidth: _minWidth,
        minHeight: _minHeight,
        quality: _quality,
        format: CompressFormat.jpeg,
      );

      int compressedSize = imageBytes.length;

      Directory directory = await getApplicationDocumentsDirectory();
      String originalImagePath = '${directory.path}/OriginalImage.jpg';
      File originalImageFile = File(originalImagePath);
      originalImageFile.writeAsBytesSync(widget.imageFile!.readAsBytesSync());

      String compressedFileName =
          'CompressedImage_${DateTime.now().millisecondsSinceEpoch}.jpg';
      String compressedImagePath = '${directory.path}/$compressedFileName';
      File compressedImageFile = File(compressedImagePath);
      compressedImageFile.writeAsBytesSync(imageBytes);

      setState(() {
        _compressedImage = compressedImageFile;
        _originalSize =
        'Original Image Size: ${(originalSize / (1024 * 1024)).toStringAsFixed(2)} MB';
        _compressedSize =
        'Compressed Image Size: ${_formatSize(compressedSize)}';
      });

      _showDownloadDialog(compressedImageFile.path);

      _addToConversionHistory(originalImagePath, compressedImagePath,
          _originalSize, _compressedSize);
    }
    catch(e){
      print("object oops Erroor Is _compresimage $e");
    }
  }

  void _addToConversionHistory(String originalImagePath,
      String compressedImagePath, String originalSize, String compressedSize) {
    ConversionHistory newConversion = ConversionHistory(
      originalImagePath: originalImagePath,
      compressedImagePath: compressedImagePath,
      originalSize: originalSize,
      compressedSize: compressedSize,
    );

    setState(() {
      _conversionHistory.insert(
          0, newConversion); // Add to the beginning of the list
    });
  }

  String _formatSize(int sizeInBytes) {
    const int KB = 1024;
    const int MB = 1024 * KB;

    if (sizeInBytes >= MB) {
      return '${(sizeInBytes / MB).toStringAsFixed(2)} MB';
    } else {
      return '${(sizeInBytes / KB).toStringAsFixed(2)} KB';
    }
  }


// ...


// ...

  Future<void> _showDownloadDialog(String imagePath) async {
    await showDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: Text('Image Download'),
        content: Container(
          height: UIUtils.appHeight(context) * 0.25,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.file(
                File(imagePath),
                height: 100.0,
              ),
              SizedBox(height: 10),
              CupertinoButton(
                onPressed: () async {
                  final directory = await getDownloadsDirectory();
                  final downloadPath = directory!.path;
                  final fileName =
                      'CompressedImage_${DateTime.now().millisecondsSinceEpoch}.jpg';

                  final newFilePath = '$downloadPath/ImageCompresser/$fileName';

                  // Use GallerySaver to save the image
                  await GallerySaver.saveImage(imagePath);

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Image downloaded to $newFilePath'),
                    ),
                  );
                  Navigator.of(context).pop();
                },
                child: Text('Download Image'),
              ),
            ],
          ),
        ),
        actions: [
          CupertinoDialogAction(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('Cancel'),
          ),
        ],
      ),
    );
  }

  Future<void> _showInputDialog(BuildContext context) async {
    await showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: Text('Compression Settings'),
        content: Container(
          height: UIUtils.appHeight(context) * 0.2,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              // CupertinoTextField(
              //   keyboardType: TextInputType.number,
              //   placeholder: 'Min Width',
              //   prefix: Icon(Icons.photo_size_select_small),
              //   onChanged: (value) {
              //     setState(() {
              //       _minWidth = int.parse(value);
              //     });
              //   },
              // ),
              // SizedBox(height: 16),
              // CupertinoTextField(
              //   keyboardType: TextInputType.number,
              //   placeholder: 'Min Height',
              //   prefix: Icon(Icons.photo_size_select_small),
              //   onChanged: (value) {
              //     setState(() {
              //       _minHeight = int.parse(value);
              //     });
              //   },
              // ),
              SizedBox(height: 16),
              CupertinoTextField(
                keyboardType: TextInputType.number,
                placeholder: 'Quality',

                prefix: Icon(Icons.settings),
                onChanged: (value) async {
                  setState(() {


                    _quality = int.parse(value);

                    if (_quality >= 1 && _quality <= 10) {
                      _minWidth = 432;
                      _minHeight = 576;
                      print("object 10");
                    } else if (_quality >= 11 && _quality <= 20) {
                      _minWidth = 864;
                      _minHeight = 1152;
                      print("object 20");
                    } else if (_quality >= 21 && _quality <= 30) {
                      // Add more ranges as needed
                      _minWidth = 1296;
                      _minHeight = 1728;
                      print("object 30");
                    } else if (_quality >= 31 && _quality <= 40) {
                      // Add more ranges as needed
                      _minWidth = 1296;
                      _minHeight = 1728;
                      print("object 40");
                    } else if (_quality >= 41 && _quality <= 50) {
                      // Add more ranges as needed
                      _minWidth = 1296;
                      _minHeight = 1728;
                      print("object 50");
                    } else if (_quality >= 51 && _quality <= 60) {
                      // Add more ranges as needed
                      _minWidth = 1296;
                      _minHeight = 1728;
                      print("object 60");
                    } else if (_quality >= 60 && _quality <= 70) {
                      // Add more ranges as needed
                      _minWidth = 1296;
                      _minHeight = 1728;
                      print("object  70");
                    } else if (_quality >= 71 && _quality <= 80) {
                      // Add more ranges as needed
                      _minWidth = 1296;
                      _minHeight = 1728;
                      print("object 80");
                    } else if (_quality >= 81 && _quality <= 90) {
                      // Add more ranges as needed
                      _minWidth = 1296;
                      _minHeight = 1728;
                      print("object 90");
                    } else {
                      // Default values if quality doesn't match any range
                      _minWidth = 5184;
                      _minHeight = 6236;
                      print("object default");
                    }

                    //  switch(_quality){
                    //    case 10:
                    //      _minWidth = 432;
                    //      _minHeight = 576;
                    //      print("object 10");
                    //      break;
                    //   case 20:
                    //     _minWidth = 864;
                    //     _minHeight = 1152;
                    //     print("object 20");
                    //
                    //     break;
                    //   case 30:
                    //     _minWidth = 1296;
                    //     _minHeight = 1728;
                    //     print("object 30");
                    //
                    //     break;
                    //   case 40:
                    //     _minWidth = 1728;
                    //     _minHeight = 2304;
                    //     print("object 40");
                    //
                    //     break;
                    //   case 50:
                    //     _minWidth = 2160;
                    //     _minHeight = 2880;
                    //     print("object 50");
                    //
                    //     break;
                    //   case 60:
                    //     _minWidth = 2592;
                    //     _minHeight = 3456;
                    //     print("object 60");
                    //
                    //     break;
                    //   case 70:
                    //     _minWidth = 3024;
                    //     _minHeight = 4032;
                    //     print("object 70");
                    //
                    //     break;
                    //   case 80:
                    //     _minWidth = 3456;
                    //     _minHeight = 4608;
                    //     print("object 80");
                    //
                    //     break;
                    //   case 90:
                    //     _minWidth = 3888;
                    //     _minHeight = 5184;
                    //     print("object 90");
                    //
                    //     break;
                    //
                    //    default:
                    //     _minWidth = 5184;
                    //     _minHeight = 6236;
                    //     print("object default");
                    //
                    //     break;
                    // }
                  });
                },
              ),
            ],
          ),
        ),
        actions: [
          CupertinoDialogAction(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('Cancel'),
          ),
          CupertinoDialogAction(
            onPressed: () {
              Navigator.of(context).pop();
              _compressImage();
            },
            child: Text('Compress'),
          ),
        ],
      ),
    );
  }



  Future<void> shareImage(String imagePath) async {
    try {
      final File imageFile = File(imagePath);

      if (await imageFile.exists()) {
        // Share the image using the share_plus package
        await Share.shareFiles([imagePath], text: 'Check out this image!');
      } else {
        print('Error sharing image: File does not exist.');
      }
    } catch (e) {
      print('Error sharing image: $e');
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Image Processing"),
      ),
      body: Stack(
        children: [
          Container(
            height: UIUtils.appHeight(context),
            child: Column(
              // mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(top: 15.0,bottom: 10,right: 10,left: 10),
                  child: InkWell(
                      onTap: (){
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ImageDetailsScreen(
                              originalImagePath: widget.imageFile!.path,
                              compressedImagePath: _compressedImage != null
                                  ? _compressedImage!.path
                                  : '',
                              originalSize: _originalSize,
                              compressedSize: _compressedSize,
                            ),
                          ),
                        );

                      },
                      child: Container(
                        height: UIUtils.appHeight(context) * 0.65,
                        padding: const EdgeInsets.all(16.0),
                        decoration: BoxDecoration(
                            border: Border.all(width: 5, color: AppColor.appThemeColors,),
                            borderRadius: BorderRadius.all(Radius.circular(50)),
                            image: DecorationImage(
                                image: FileImage(widget.imageFile!),
                                fit: BoxFit.fill
                            )
                        ),
                        // child: Image.file(widget.imageFile!, height: 200, width: 200)
                      )
                  ),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
          Positioned.fill(
            // bottom: 10,
            top: UIUtils.appHeight(context) * 0.75,
            // alignment: Alignment.bottomCenter,
            child: Container(
              // color: Colors.red,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildCircularButton(
                    onPressed: () => _cropImage(context),
                    icon: Icons.crop,
                    text: 'Crop',
                  ),
                  _buildCircularButton(
                    onPressed: () {
                      _showInputDialog(context);},
                    icon: Icons.compress,
                    text: 'Compress',
                  ),
                  _buildCircularButton(
                    onPressed: () {
                      // Navigator.push(
                      //   context,
                      //   MaterialPageRoute(
                      //     builder: (context) => ImageDetailsScreen(
                      //       originalImagePath: widget.imageFile!.path,
                      //       compressedImagePath: _compressedImage != null
                      //           ? _compressedImage!.path
                      //           : '',
                      //       originalSize: _originalSize,
                      //       compressedSize: _compressedSize,
                      //     ),
                      //   ),
                      // );

                      print("object Comprssred image path ${_compressedImage?.path}");
                      try {
                        if (_compressedImage != null && File(_compressedImage!.path).existsSync()) {
                          shareImage(_compressedImage!.path);
                        }else{

                        }
                      } catch (e) {
                        print('Error: $e');
                      }                    },
                    icon: Icons.share,
                    text: 'Share',
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
/*
  void _showActionSheet(BuildContext context) {
    showCupertinoModalPopup<void>(
      context: context,
      builder: (BuildContext context) => CupertinoActionSheet(
        // title: const Text('Select Type'),
        message: const Text('Select Type'),
        actions: <CupertinoActionSheetAction>[
          CupertinoActionSheetAction(
            /// This parameter indicates the action would be a default
            /// default behavior, turns the action's text to bold text.
            isDefaultAction: true,
            onPressed: () {
              Navigator.pop(context);
              _showInputDialog(context,0);
            },
            child: const Text('Small'),
          ),
          CupertinoActionSheetAction(
            onPressed: () {
              Navigator.pop(context);
              _showInputDialog(context,2);
            },
            child: const Text('Medium'),
          ),
          CupertinoActionSheetAction(
            /// This parameter indicates the action would perform
            /// a destructive action such as delete or exit and turns
            /// the action's text color to red.
            onPressed: () {
              Navigator.pop(context);
              _showInputDialog(context,2);
            },
            child: const Text('Large'),
          ),
        ],
      ),
    );
  }
*/

  Widget _buildCircularButton({
    required VoidCallback onPressed,
    required IconData icon,
    required String text,
  }) {
    return GestureDetector(
      onTap: onPressed,
      child: Column(
        children: [
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppColor.appThemeColors,
                border: Border.all(color:AppColor.containerColors,width: 2),
                boxShadow: [
                  BoxShadow(
                      color: Colors.grey.shade600,
                      spreadRadius: 0,
                      blurRadius: 6
                  )
                ]
            ),
            child: Icon(
              icon,
              color: Colors.white,
            ),
          ),
          SizedBox(height: 8),
          Text(text),
        ],
      ),
    );
  }
}

/*
class ImageDetailsScreen extends StatelessWidget {
  final String originalImagePath;
  final String compressedImagePath;
  final String originalSize;
  final String compressedSize;

  ImageDetailsScreen({
    required this.originalImagePath,
    required this.compressedImagePath,
    required this.originalSize,
    required this.compressedSize,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Image Details"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.file(File(originalImagePath), height: 200, width: 200),
            SizedBox(height: 20),
            Text(originalSize),
            SizedBox(height: 20),
            if (compressedImagePath.isNotEmpty)
              Column(
                children: [
                  Image.file(File(compressedImagePath), height: 200, width: 200),
                  SizedBox(height: 20),
                  Text(compressedSize),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      final directory = await getDownloadsDirectory();
                      final downloadPath = directory!.path;
                      final fileName =
                          'CompressedImage_${DateTime.now().millisecondsSinceEpoch}.jpg';

                      final newFilePath = '$downloadPath/$fileName';

                      File(compressedImagePath).copySync(newFilePath);

                      ScaffoldMessenger.of(context).showSnackBar(
                        SnackBar(
                          content: Text('Image downloaded to $newFilePath'),
                        ),
                      );
                    },
                    child: Text('Download Compressed Image'),
                  ),
                ],
              ),
          ],
        ),
      ),
    );
  }
}
*/
