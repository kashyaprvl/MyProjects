import 'package:flutter/material.dart';
import 'package:image_compress/utlis/colors.dart';
import 'package:image_picker/image_picker.dart';
import 'dart:io';

import 'image_compres_screen.dart';
class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {

  File? _image;

  Future<File?> _getImage(String type) async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source:(type == 'gallery')?ImageSource.gallery: ImageSource.camera);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
      });
      print("object  nldxl  ${_image}");
      print("object  nldxl  ${_image!.path}");
      return _image;
    }
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Image Compresser"),
        centerTitle: true,
      ),
      backgroundColor: Colors.yellow.shade200,

      body: Container(
        decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/pexels-photo-6177645.jpeg"),fit: BoxFit.cover
            )
        ),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            getCircullerImage(AppColor.containerColors,Icon(Icons.camera,size: 35,color: Colors.white,), onTap: () {
              print("object Camerais On");
              _getImage('Camera')..then((value) {
                if (value != null) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ImageProcessingScreen(imageFile: value),
                    ),
                  );
                }
              });;
            }),
            SizedBox(width: 20,),
            getCircullerImage(AppColor.containerColors,Icon(Icons.add_chart_outlined,size: 35,color: Colors.white,),onTap: (){
              print("object");
              _getImage('gallery').then((value) {
                if (value != null) {
                  Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) => ImageProcessingScreen(imageFile: value),
                    ),
                  );
                }
              });
            }),

          ],
        ),
      ),

    );
  }

  Widget getCircullerImage(Color color,Icon icon ,{required final VoidCallback onTap,}){
    return   Center(
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          width: 100.0, // Adjust the size as needed
          height: 100.0, // Adjust the size as needed
          decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: color,
              boxShadow: [
                BoxShadow(
                    blurStyle: BlurStyle.outer,
                    color: Colors.white,
                    spreadRadius: 0,
                    blurRadius: 15
                )
              ],
              border: Border.all(color:AppColor.borderWhiteColors,width: 2)
          ),
          child: Center(
            child: icon,
          ),
        ),
      ),
    );
  }
}
