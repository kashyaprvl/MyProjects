import 'dart:io';

import 'package:flutter/material.dart';

class ImageDetailsScreen extends StatelessWidget {
  final List<String> originalImagePaths;
  final List<String> compressedImagePaths;
  final List<String> originalSizes;
  final List<String> compressedSizes;

  ImageDetailsScreen({
    required this.originalImagePaths,
    required this.compressedImagePaths,
    required this.originalSizes,
    required this.compressedSizes,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Image Details'),
      ),
      body: ListView.builder(
        itemCount: originalImagePaths.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text('Image ${index + 1}'),
            subtitle: Text('Original Size: ${originalSizes[index]}\nCompressed Size: ${compressedSizes[index]}'),
            leading: Image.file(File(compressedImagePaths[index]), width: 100, height: 100, fit: BoxFit.cover),
          );
        },
      ),
    );
  }
}
