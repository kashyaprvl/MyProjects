import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'dart:io';
import '../multipleimage/image_compreesing_screen.dart';

class ImageSelectionScreen extends StatefulWidget {
  List<File>? selectedImages = [];
  ImageSelectionScreen({super.key,this.selectedImages});

  @override
  _ImageSelectionScreenState createState() => _ImageSelectionScreenState();
}

class _ImageSelectionScreenState extends State<ImageSelectionScreen> {
  // List<File> _selectedImages = [];
  double _quality = 50; // Compression quality

  Future<void> _pickImages() async {
    final List<XFile>? pickedFiles = await ImagePicker().pickMultiImage();
    if (pickedFiles != null) {
      setState(() {
        widget.selectedImages = pickedFiles.map((file) => File(file.path)).toList();
      });
    }
  }

  Future<XFile> _compressImage(File file) async {
    final dir = await getTemporaryDirectory();
    String targetPath = dir.absolute.path + "/${DateTime.now().millisecondsSinceEpoch}.jpg";
    final  result = await FlutterImageCompress.compressAndGetFile(
      file.absolute.path, targetPath, quality: _quality.toInt(),
    );
    return result!;
  }

  void _compressAllImages() async {
    List<String> originalImagePaths = [];
    List<String> compressedImagePaths = [];
    List<String> originalSizes = [];
    List<String> compressedSizes = [];

    for (var image in widget.selectedImages!) {
      var compressedImage = await _compressImage(image);

      originalImagePaths.add(image.path);
      compressedImagePaths.add(compressedImage.path);
      originalSizes.add(_formatFileSize(image.lengthSync()));
      compressedSizes.add(_formatFileSize(File(compressedImage!.path).lengthSync()));
    }

    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (context) => ImageDetailsScreen(
          originalImagePaths: originalImagePaths,
          compressedImagePaths: compressedImagePaths,
          originalSizes: originalSizes,
          compressedSizes: compressedSizes,
        ),
      ),
    );
  }

  String _formatFileSize(int bytes) {
    const kilobyte = 1024;
    const megabyte = 1024 * kilobyte;

    if (bytes >= megabyte) {
      return '${(bytes / megabyte).toStringAsFixed(2)} MB';
    } else if (bytes >= kilobyte) {
      return '${(bytes / kilobyte).toStringAsFixed(2)} KB';
    } else {
      return '$bytes bytes';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Select and Compress Images'),
        actions: [
          IconButton(
            icon: Icon(Icons.add_a_photo),
            onPressed: _pickImages,
          ),
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              itemCount: widget.selectedImages?.length,
              itemBuilder: (context, index) {
                return ListTile(
                  leading: Image.file(widget.selectedImages![index], width: 100, height: 100, fit: BoxFit.cover),
                  title: Text('Image ${index + 1}'),
                );
              },
            ),
          ),
          Slider(
            value: _quality,
            min: 0,
            max: 100,
            divisions: 100,
            label: 'Quality: ${_quality.toInt()}',
            onChanged: (double value) {
              setState(() {
                _quality = value;
              });
            },
          ),
          ElevatedButton(
            onPressed: _compressAllImages,
            child: Text('Compress Images'),
          ),
        ],
      ),
    );
  }
}
