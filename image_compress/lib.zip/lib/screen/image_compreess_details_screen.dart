import 'dart:io';

import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:image_compress/utlis/uiUtils.dart';
import 'package:image_compress/widget/appbar.dart';
import 'package:share_plus/share_plus.dart';

import '../model/hivedatamodel.dart';
import '../utlis/colors.dart';
import 'history_screen.dart';

class ImageDetailsScreen extends StatefulWidget {
  final List<String> originalImagePaths;
  final List<String> compressedImagePaths;
  final List<String> originalSizes;
  final List<String> compressedSizes;

  ImageDetailsScreen({
    required this.originalImagePaths,
    required this.compressedImagePaths,
    required this.originalSizes,
    required this.compressedSizes,
  });

  @override
  State<ImageDetailsScreen> createState() => _ImageDetailsScreenState();
}

class _ImageDetailsScreenState extends State<ImageDetailsScreen> {
  int totalSize = 0;
  @override
  void initState() {
    super.initState();
    calculateTotalSize();
  }
  Future<void> calculateTotalSize() async {

    List<File> imageFiles = [];

    for (String tempStrin in  widget.compressedImagePaths ){
      imageFiles.add(File(tempStrin));
    }
    int calculatedSize = 0;

    for (File file in imageFiles) {
      int fileSize = await file.length();
      calculatedSize += fileSize;
    }

    setState(() {
      totalSize = calculatedSize;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:CustomAppBar(
          showIcon: true,
        leftIconPath: "assets/svg/back_arrow_svg.svg",
        leftOnPressed: (){
            Navigator.pop(context);
        },
        rightIconPath: "assets/svg/download_svg.svg",
        rightOnPressed: (){
            print("object my work is clicked");
            Navigator.push(context, MaterialPageRoute(builder: (context) => ImageHistoryList()));
        },
      ),
      body:
        SingleChildScrollView(
          physics: BouncingScrollPhysics(),

          child: Padding(
            padding: const EdgeInsets.only(left: 15.0,right: 15,top: 15,bottom: 10),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
              if( widget.originalImagePaths.length > 1)...[
                Column(
                  children: [
                    Container(
                      height: UIUtils.appHeight(context) * 0.6,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: const Color.fromRGBO(255, 255, 255, 1),
                          boxShadow:   [
                            BoxShadow(
                              color: Colors.grey.shade300,
                              spreadRadius: 0,
                              blurRadius: 1,
                            )
                          ]

                      ),
                      padding: EdgeInsets.only(left: 25,top: 10,bottom: 10,right: 10),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Row(
                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Container(
                                    decoration: BoxDecoration(
                                      shape: BoxShape.circle,
                                      // borderRadius: BorderRadius.circular(15),
                                      color: AppColor.cardBackgroungDarkColor,

                                    ),
                                    height: 40,
                                    width: 40,
                                    child: Padding(
                                      padding: const EdgeInsets.all(8.0),
                                      child: SvgPicture.asset(
                                        "assets/svg/image_logo.svg",
                                        color: Colors.white,
                                        width: 150,
                                        height: 150,
                                        fit: BoxFit.cover,
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: const EdgeInsets.only(left: 8.0),
                                    child: Text("Result Image",style: GoogleFonts.mulish(
                                        fontSize: 16,
                                        fontWeight: FontWeight.w700
                                    ),),
                                  ),


                                ],
                              ),
                              Container(
                               padding: EdgeInsets.all(5),
                                decoration: BoxDecoration(
                                  color: AppColor.cardBackgroungDarkColor,
                                  boxShadow: [
                                    BoxShadow(
                                      color: AppColor.cardBackgroungDarkColor,
                                      spreadRadius: 0
                                    )
                                  ],
                                  borderRadius: BorderRadius.circular(35)
                                ),
                                child: Text("${widget.compressedImagePaths.length} Images",style: GoogleFonts.mulish(fontWeight: FontWeight.w600,color: AppColor.borderWhiteColors,),)
                              )
                            ],
                          ),

                          const  SizedBox(height: 10,),
                          SizedBox(
                            height: UIUtils.appHeight(context) * 0.45,
                            child: ListView.builder(
                                // scrollDirection: Axis.horizontal,
                                shrinkWrap: true,
                                itemCount: widget.compressedImagePaths.length ,
                                itemBuilder: (context,index) {
                                  return Container(
                                    child: Row(
                                      children: [
                                        Container(
                                          width: UIUtils.appWidth(context) * 0.4,
                                          child: Container(

                                              height: UIUtils.appHeight(context) * 0.3,
                                              width: UIUtils.appWidth(context) * 0.3,// width: 250,
                                              // width: 250,
                                              margin: EdgeInsets.all(5),
                                              decoration: BoxDecoration(
                                                  borderRadius: BorderRadius.circular(15),
                                                  image: DecorationImage(
                                                    image: FileImage(File(widget.compressedImagePaths![index])),
                                                    fit: BoxFit.fill,

                                                  )
                                              ),
                                        )
                                        ),
                                        Container(
                                          width: UIUtils.appWidth(context) * 0.4,
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              RichText(
                                                text: TextSpan(
                                                  text: 'Compress Size:',
                                                  style: GoogleFonts.mulish(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 12),
                                                  children: [
                                                    TextSpan(
                                                      text: ' ${UIUtils.formatFileSize(File(widget.compressedImagePaths[index]).lengthSync())}',
                                                      style: GoogleFonts.mulish(color: Colors.grey.shade400,fontWeight: FontWeight.w600,fontSize: 12),
                                                    ),

                                                  ],
                                                ),
                                              ),
                                              RichText(
                                                text: TextSpan(
                                                  text: 'Original  Size:',
                                                  style: GoogleFonts.mulish(color: Colors.black,fontWeight: FontWeight.w600,fontSize: 12),
                                                  children: [
                                                    TextSpan(
                                                      text: ' ${UIUtils.formatFileSize(File(widget.originalImagePaths[index]).lengthSync())}',
                                                      style: GoogleFonts.mulish(color: Colors.grey.shade400,fontWeight: FontWeight.w600,fontSize: 12),
                                                    ),

                                                  ],
                                                ),
                                              )
                                            ],
                                          ),
                                        )
                                      ],
                                    ),
                                  );
                                }
                            ),
                          ),

                        ],
                      ),
                    ),

                    SizedBox(height: 15,),

                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        /// Save Tap  Single image Code

                        Container(
                          width: UIUtils.appWidth(context) * 0.43,
                          height: 45,
                          decoration: BoxDecoration(
                              color: AppColor.cardBackgroungDarkColor,
                              borderRadius: BorderRadius.circular(35)

                          ),
                          child: InkWell(
                            onTap: ()async{
                              print("object multiple path is ${widget.originalImagePaths}");
                              List<ImageHistory> newHistory = [];

                              for(int i = 0 ;i < widget.compressedImagePaths.length;i++) {
                                newHistory.add(ImageHistory(
                                  originalPath: '${widget.originalImagePaths[i]}',
                                  compressedPath: '${widget
                                      .compressedImagePaths[i]}',
                                  timestamp: DateTime.now(),
                                ));
                              }

                              // Save the ImageHistory
                              await UIUtils.saveImageHistory(newHistory);

                            },
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  "assets/svg/save_file.svg",
                                  width: 30,
                                  height: 30,
                                  fit: BoxFit.cover,
                                ),
                                Text("SAVE",style: GoogleFonts.mulish(textStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: Colors.white)),)

                              ],
                            ),
                          ),
                        ),

                        Container(
                          width: UIUtils.appWidth(context) * 0.43,
                          height: 45,
                          decoration: BoxDecoration(
                              color: AppColor.cardBackgroungLightColor,
                              borderRadius: BorderRadius.circular(35)

                          ),
                          /// Share Single Image Tap Code
                          child: InkWell(
                            onTap: (){
                              UIUtils.shareImage(widget.compressedImagePaths);
                            },
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  "assets/svg/share.svg",
                                  width: 30,
                                  height: 30,
                                  fit: BoxFit.cover,
                                ),
                                Text("SHARE",style: GoogleFonts.mulish(textStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: AppColor.appBlackColor)),)

                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                    /// Download Single Image  Tap Code
                    SizedBox(height: UIUtils.appHeight(context) * 0.05,),
                    Container(
                      width: UIUtils.appWidth(context) * 0.89,
                      height: 50,
                      decoration: BoxDecoration(
                          color: AppColor.cardBackgroungLightColor,
                          borderRadius: BorderRadius.circular(35)

                      ),

                      child: InkWell(
                        onTap: (){

                          UIUtils.appImageSaveDownload(widget.compressedImagePaths);

                        },
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [

                            Text("download Image".toUpperCase(),style: GoogleFonts.mulish(textStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: AppColor.appBlackColor)),)

                          ],
                        ),
                      ),
                    )

                  ],
                ),
              ],
              if(widget.originalImagePaths.length == 1)...[
                Column(
                  children: [
                    Container(
                      height: UIUtils.appHeight(context) * 0.65,
                      decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(15),
                          color: Color.fromRGBO(255, 255, 255, 1),
                          boxShadow: [
                            new BoxShadow(
                              color: Colors.grey,
                              spreadRadius: 0,
                              blurRadius: 1,
                            )
                          ]

                      ),
                      // color: Colors.red,
                      padding: EdgeInsets.only(left: 25,top: 10,bottom: 10,right: 10),

                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.start,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [

                          Row(
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Container(
                                decoration: BoxDecoration(
                                  shape: BoxShape.circle,
                                  // borderRadius: BorderRadius.circular(15),
                                  color: AppColor.cardBackgroungDarkColor,

                                ),
                                height: 40,
                                width: 40,
                                child: Padding(
                                  padding: const EdgeInsets.all(8.0),
                                  child: SvgPicture.asset(
                                    "assets/svg/image_logo.svg",
                                    color: Colors.white,
                                    width: 150,
                                    height: 150,
                                    fit: BoxFit.cover,
                                  ),
                                ),
                              ),
                              Padding(
                                padding: const EdgeInsets.only(left: 8.0),
                                child: Text("Compress Photo",style: GoogleFonts.mulish(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w700
                                ),),
                              ),


                            ],
                          ),

                          SizedBox(height: 10,),

                          Row(
                            children: [
                              Container(
                                height: UIUtils.appHeight(context) * 0.48,
                                width: UIUtils.appWidth(context) * 0.37,
                                // height: 150,
                                // width: UIUtils.appWidth(context) * 0.37,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  image: DecorationImage(
                                    image:  FileImage(File(widget.originalImagePaths.first)),fit: BoxFit.fill
                                  )
                                ),
                              ),

                              SizedBox(width: 15,),
                              Container(
                                height: UIUtils.appHeight(context) * 0.48,
                                width: UIUtils.appWidth(context) * 0.37,
                                decoration: BoxDecoration(
                                  borderRadius: BorderRadius.circular(15),
                                  image: DecorationImage(
                                    image:  FileImage(File(widget.compressedImagePaths.first)),fit: BoxFit.contain
                                  )
                                ),
                              )
                            ],
                          ),
                          Row(
                            children: [
                              Container(
                                height: 50,
                                width: UIUtils.appWidth(context) * 0.37,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text("Before",style: GoogleFonts.mulish(fontWeight: FontWeight.w500,fontSize: 16),),
                                    Text("${UIUtils.formatFileSize(File(widget.originalImagePaths.first).lengthSync())}",style: GoogleFonts.mulish(fontWeight: FontWeight.w500,fontSize: 16,color: Color.fromRGBO(161, 161, 161, 1)),)
                                  ],
                                ),
                              ),

                              SizedBox(width: 15,),

                              Container(
                                height: 50,
                                width: UIUtils.appWidth(context) * 0.37,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Text("After",style: GoogleFonts.mulish(fontWeight: FontWeight.w500,fontSize: 16),),
                                    Text("${UIUtils.formatFileSize(File(widget.compressedImagePaths.first).lengthSync())}",style: GoogleFonts.mulish(fontWeight: FontWeight.w500,fontSize: 16,color: Color.fromRGBO(161, 161, 161, 1)),)
                                  ],
                                ),
                              ),

                            ],
                          )



                        ],
                      ),
                    ),
                    
                    SizedBox(height: 15,),
                    
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        /// Save Tap  Single image Code

                        Container(
                          width: UIUtils.appWidth(context) * 0.43,
                          height: 45,
                          decoration: BoxDecoration(
                            color: AppColor.cardBackgroungDarkColor,
                            borderRadius: BorderRadius.circular(35)

                          ),
                          child: InkWell(
                            onTap: ()async{
                              List<ImageHistory> newHistory = [];

                              for(int i = 0 ;i < widget.compressedImagePaths.length;i++) {
                                newHistory.add(ImageHistory(
                                  originalPath: '${widget.originalImagePaths[i]}',
                                  compressedPath: '${widget
                                      .compressedImagePaths[i]}',
                                  timestamp: DateTime.now(),
                                ));
                              }


                              // Save the ImageHistory
                              await UIUtils.saveImageHistory(newHistory);

                            },
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  "assets/svg/save_file.svg",
                                  width: 25,
                                  height: 25,
                                  fit: BoxFit.cover,
                                ),
                                Text("SAVE",style: GoogleFonts.mulish(textStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: Colors.white)),)

                              ],
                            ),
                          ),
                        ),

                        Container(
                          width: UIUtils.appWidth(context) * 0.43,
                          height: 45,
                          decoration: BoxDecoration(
                            color: AppColor.cardBackgroungLightColor,
                            borderRadius: BorderRadius.circular(35)

                          ),
                          /// Share Single Image Tap Code
                          child: InkWell(
                            onTap: (){
                              UIUtils.shareImage(widget.compressedImagePaths);
                            },
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.center,
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                SvgPicture.asset(
                                  "assets/svg/share.svg",
                                  width: 25,
                                  height: 25,
                                  fit: BoxFit.cover,
                                ),
                                Text("SHARE",style: GoogleFonts.mulish(textStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: AppColor.appBlackColor)),)

                              ],
                            ),
                          ),
                        )
                      ],
                    ),
                    /// Download Single Image  Tap Code
                   SizedBox(height: UIUtils.appHeight(context) * 0.1,),
                    Container(
                      width: UIUtils.appWidth(context) * 0.89,
                      height: 50,
                      decoration: BoxDecoration(
                          color: AppColor.cardBackgroungLightColor,
                          borderRadius: BorderRadius.circular(35)

                      ),

                      child: InkWell(
                        onTap: (){

                          UIUtils.appImageSaveDownload(widget.compressedImagePaths);

                        },
                        child: Row(
                          crossAxisAlignment: CrossAxisAlignment.center,
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [

                            Text("download Image".toUpperCase(),style: GoogleFonts.mulish(textStyle: TextStyle(fontSize: 16,fontWeight: FontWeight.w600,color: AppColor.appBlackColor)),)

                          ],
                        ),
                      ),
                    )


                    
                  ],
                )
              ]
            ],),
          ),
        )

    );
  }



}
