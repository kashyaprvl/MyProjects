import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';

import '../utlis/colors.dart';

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget {
    CustomAppBar({super.key ,this.leftIconPath,this.rightOnPressed,this.rightIconPath,this.leftOnPressed,required this.showIcon});
  String? leftIconPath ;
  String? rightIconPath ;
    VoidCallback? leftOnPressed;
   VoidCallback? rightOnPressed;
   bool showIcon = false;

  final double appBarHeight = 100.0;

  @override
  Size get preferredSize => Size.fromHeight(appBarHeight);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Colors.white,
      elevation: 0,
      title: (showIcon == true)?Image.asset(
        "assets/splashLogo.png",
        width: 50,
        height: 50,
        fit: BoxFit.fill,
      ):SizedBox.shrink(),
      leading: Text(""),
      leadingWidth: 0,
      centerTitle: true,
      toolbarHeight: appBarHeight,
      flexibleSpace: Container(
        height: appBarHeight,
        padding: const EdgeInsets.only(top: 12.0, left: 10, right: 10),
        child: Container(
          margin: EdgeInsets.only(right: 10, left: 10, top: 25, bottom: 0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              (leftIconPath != null)?_buildIconButton(
                icon: leftIconPath!,
                onPressed: leftOnPressed ?? () {},
              ):SizedBox.shrink(),
              (rightIconPath != null)?_buildIconButton(
                icon: rightIconPath!,
                onPressed: rightOnPressed?? (){},
              ):SizedBox.shrink(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildIconButton({
    required String icon,
    required VoidCallback onPressed,
  }) {
    return Container(
      padding: EdgeInsets.all(5),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(15),
        color: AppColor.cardBackgroungColor,

      ),
      height: 40,
      width: 40,
      child: InkWell(
        onTap: onPressed,
        child: SvgPicture.asset(
         icon,
          width: 150,
          height: 100,
          fit: BoxFit.cover,
        ),
      ),
    );
  }

  void _onIconButtonPressed(BuildContext context, String action) {
    // Handle the button press based on the action (Camera/Download)
    // You can navigate to different screens or perform any other action.
    // Example:
    if (action == "Camera") {
      // Handle Camera button press
    } else if (action == "Download") {
      // Handle Download button press
    }
  }



}
