import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/cupertino.dart';
import 'package:image_compress/screen/home_screen.dart';
import 'package:image_compress/screen/multipleimage/image_seltion_screen.dart';
import 'package:image_compress/screen/splash_acreen.dart';
import 'package:image_compress/utlis/colors.dart';
import 'package:image_compress/utlis/uiUtils.dart';
import 'package:image_picker/image_picker.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path_provider/path_provider.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:path_provider/path_provider.dart' as path_provider;

import 'model/hivedatamodel.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  final appDocumentDirectory = await path_provider.getApplicationDocumentsDirectory();
  Hive.init(appDocumentDirectory.path);
  Hive.registerAdapter(ImageHistoryAdapter());
  boxSaveData = await Hive.openBox<ImageHistory>('imageHistoryBox');



  runApp(MyApp());
}

class ConversionHistory {
  String originalImagePath;
  String compressedImagePath;
  String originalSize;
  String compressedSize;

  ConversionHistory({
    required this.originalImagePath,
    required this.compressedImagePath,
    required this.originalSize,
    required this.compressedSize,
  });
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(

      debugShowCheckedModeBanner: false,
      // home: HomeScreen(),
      // home: ImageSelectionScreen(),
      routes: {
        '/': (context) => const SplashScreen(),
        "/home": (context) =>   HomeScreen()

      },
      initialRoute: "/",
      // home: SplashScreen(),
      theme: ThemeData(
        appBarTheme: AppBarTheme(
            backgroundColor: AppColor.appBarColors
        ),
        primarySwatch:Colors.blue,
      ),
    );
  }
}

class MyHomePage extends StatefulWidget {
  @override
  _MyHomePageState createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  File? _image;
  File? _compressedImage;
  String _originalSize = '';
  String _compressedSize = '';
  int _minWidth = 1920;
  int _minHeight = 1080;
  int _quality = 95;

  List<ConversionHistory> _conversionHistory = [];

  @override
  void initState() {
    super.initState();
    _conversionHistory = List<ConversionHistory>.generate(
      5,
          (index) => ConversionHistory(
        originalImagePath: 'Original Image $index',
        compressedImagePath: 'Compressed Image $index',
        originalSize: 'Original Size $index',
        compressedSize: 'Compressed Size $index',
      ),
    );
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        _image = File(pickedFile.path);
        _compressedImage =
        null; // Reset compressed image when a new image is picked.
        _originalSize = '';
        _compressedSize = '';
      });
    }
  }

  Future<void> _compressImage() async {
    if (_image == null) {
      // Handle case when no image is selected.
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Please select an image before compressing.'),
        ),
      );
      return;
    }

    // Get the size of the original image
    int originalSize = await _image!.length();

    List<int> imageBytes = await FlutterImageCompress.compressWithList(
      _image!.readAsBytesSync(),
      minWidth: _minWidth,
      minHeight: _minHeight,
      quality: _quality,
      format: CompressFormat.jpeg,
    );

    // Get the size of the compressed image
    int compressedSize = imageBytes.length;

    Directory directory = await getApplicationDocumentsDirectory();
    String originalImagePath = '${directory.path}/OriginalImage.jpg';
    File originalImageFile = File(originalImagePath);
    originalImageFile.writeAsBytesSync(_image!.readAsBytesSync());

    String compressedFileName =
        'CompressedImage_${DateTime.now().millisecondsSinceEpoch}.jpg';
    String compressedImagePath = '${directory.path}/$compressedFileName';
    File compressedImageFile = File(compressedImagePath);
    compressedImageFile.writeAsBytesSync(imageBytes);

    setState(() {
      _compressedImage = compressedImageFile;
      _originalSize =
      'Original Image Size: ${(originalSize / (1024 * 1024)).toStringAsFixed(2)} MB';
      _compressedSize = 'Compressed Image Size: ${_formatSize(compressedSize)}';
    });

    // Optionally, show a pop-up or navigate to a new screen for the user to download the image.
    _showDownloadDialog(compressedImageFile.path);

    // Add the conversion to the history
    _addToConversionHistory(
        originalImagePath, compressedImagePath, _originalSize, _compressedSize);
  }

  void _addToConversionHistory(String originalImagePath,
      String compressedImagePath, String originalSize, String compressedSize) {
    ConversionHistory newConversion = ConversionHistory(
      originalImagePath: originalImagePath,
      compressedImagePath: compressedImagePath,
      originalSize: originalSize,
      compressedSize: compressedSize,
    );

    setState(() {
      _conversionHistory.insert(
          0, newConversion); // Add to the beginning of the list
    });
  }

  String _formatSize(int sizeInBytes) {
    const int KB = 1024;
    const int MB = 1024 * KB;

    if (sizeInBytes >= MB) {
      return '${(sizeInBytes / MB).toStringAsFixed(2)} MB';
    } else {
      return '${(sizeInBytes / KB).toStringAsFixed(2)} KB';
    }
  }

  Future<void> _showInputDialog() async {
    await showCupertinoDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: Text('Compression Settings'),
        content: Container(
          height: UIUtils.appHeight(context) * 0.35,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              CupertinoTextField(
                keyboardType: TextInputType.number,
                placeholder: 'Min Width',
                prefix: Icon(Icons.photo_size_select_small),
                onChanged: (value) {
                  setState(() {
                    _minWidth = int.parse(value);
                  });
                },
              ),
              SizedBox(height: 16),
              CupertinoTextField(
                keyboardType: TextInputType.number,
                placeholder: 'Min Height',
                prefix: Icon(Icons.photo_size_select_small),
                onChanged: (value) {
                  setState(() {
                    _minHeight = int.parse(value);
                  });
                },
              ),
              SizedBox(height: 16),
              CupertinoTextField(
                keyboardType: TextInputType.number,
                placeholder: 'Quality',
                prefix: Icon(Icons.settings),
                onChanged: (value) {
                  setState(() {
                    _quality = int.parse(value);
                  });
                },
              ),
            ],
          ),
        ),
        actions: [
          CupertinoDialogAction(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('Cancel'),
          ),
          CupertinoDialogAction(
            onPressed: () {
              Navigator.of(context).pop();
              _compressImage();
            },
            child: Text('Compress'),
          ),
        ],
      ),
    );
  }

  Future<void> _showDownloadDialog(String imagePath) async {
    await showDialog(
      context: context,
      builder: (context) => CupertinoAlertDialog(
        title: Text('Image Download'),
        content: Container(
          height: UIUtils.appHeight(context) * 0.25,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Image.file(
                File(imagePath),
                height: 100.0,
              ),
              SizedBox(height: 10),
              CupertinoButton(
                onPressed: () async {
                  final directory = await getDownloadsDirectory();
                  final downloadPath = directory!.path;
                  final fileName =
                      'CompressedImage_${DateTime.now().millisecondsSinceEpoch}.jpg';

                  final newFilePath = '$downloadPath/$fileName';

                  File(imagePath).copySync(newFilePath);

                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Image downloaded to $newFilePath'),
                    ),
                  );
                  Navigator.of(context).pop();
                },
                child: Text('Download Image'),
              ),
            ],
          ),
        ),
        actions: [
          CupertinoDialogAction(
            onPressed: () {
              Navigator.of(context).pop();
            },
            child: Text('Cancel'),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: Text('Image Compression Example'),
          bottom: TabBar(
            tabs: [
              Tab(icon: Icon(Icons.camera)),
              Tab(icon: Icon(Icons.history)),
            ],
          ),
        ),
        body: TabBarView(
          children: [
            Center(
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: <Widget>[
                    _image != null
                        ? Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(8.0),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.grey.withOpacity(0.5),
                            spreadRadius: 0,
                            blurRadius: 5,
                            offset: Offset(0, 3),
                          ),
                        ],
                      ),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(8.0),
                        child: Stack(
                          alignment: Alignment.center,
                          children: [
                            Image.file(
                              _image!,
                              height: 150.0,
                              fit: BoxFit.cover,
                            ),
                            Positioned(
                              bottom: 8.0,
                              right: 8.0,
                              child: Icon(
                                Icons.location_on,
                                color: Colors.white,
                                size: 24.0,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                        : Text('No image selected'),
                    SizedBox(height: 20),
                    CupertinoButton(
                      onPressed: _pickImage,
                      child: Text('Pick Image'),
                    ),
                    SizedBox(height: 20),
                    CupertinoButton(
                      onPressed: () {
                        if (_image == null) {
                          // Handle case when no image is selected.
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(
                              content: Text(
                                  'Please select an image before compressing.'),
                            ),
                          );
                        } else {
                          _showInputDialog();
                        }
                      },
                      child: Text('Compress Image (Custom)'),
                    ),
                    SizedBox(height: 20),
                    _compressedImage != null
                        ? GestureDetector(
                      onTap: () {
                        _showDownloadDialog(_compressedImage!.path);
                      },
                      child: Column(
                        children: [
                          Container(
                            decoration: BoxDecoration(
                              borderRadius: BorderRadius.circular(8.0),
                              boxShadow: [
                                BoxShadow(
                                  color: Colors.grey.withOpacity(0.5),
                                  spreadRadius: 0,
                                  blurRadius: 5,
                                  offset: Offset(0, 3),
                                ),
                              ],
                            ),
                            child: ClipRRect(
                              borderRadius: BorderRadius.circular(8.0),
                              child: Image.file(
                                _compressedImage!,
                                height: 150.0,
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          SizedBox(height: 10),
                          Text(_originalSize),
                          Text(_compressedSize),
                        ],
                      ),
                    )
                        : Container(),
                  ],
                ),
              ),
            ),
            // History Tab
            CupertinoPageScaffold(
                navigationBar: CupertinoNavigationBar(
                  middle: Text('Conversion History'),
                ),
                child:ListView.builder(
                  itemCount: _conversionHistory.length,
                  itemBuilder: (context, index) {
                    return ListTile(
                      title: Column(
                        children: [
                          Text(_conversionHistory[index].originalSize),
                          Text(_conversionHistory[index].compressedSize),
                        ],
                      ),
                      leading: GestureDetector(

                        onTap: ()async {
                          // _showDownloadDialog(
                          //     _conversionHistory[index].compressedImagePath);
                          // await OpenFile.open(imagePath);
                        },
                        child: ClipRRect(
                          child: Image.file(
                            File(_conversionHistory[index].compressedImagePath),
                            height: 50.0,
                          ),
                        ),
                      ),

                    );
                  },
                )
            )
          ],
        ),
      ),
    );
  }
}
/*import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Image Compressor',
      home: ImageCompressor(),
    );
  }
}

class ImageCompressor extends StatefulWidget {
  @override
  _ImageCompressorState createState() => _ImageCompressorState();
}

class _ImageCompressorState extends State<ImageCompressor> {
  File? _originalImage;
  File? _compressedImage;

  // Set the desired compression quality (between 0 and 100)
  int _quality = 50;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Image Compressor'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            if (_originalImage != null)
              Image.file(
                _originalImage!,
                height: 200,
                width: 200,
              ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                _pickImage();
              },
              child: Text('Pick Image'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () {
                _compressImage();
              },
              child: Text('Compress Image'),
            ),
            if (_compressedImage != null)
              Image.file(
                _compressedImage!,
                height: 200,
                width: 200,
              ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickImage() async {
    // Implement image picking logic using your preferred package (e.g., image_picker).
    // For simplicity, let's assume you have picked an image and assigned it to _originalImage.
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source:ImageSource.gallery);

    if (pickedFile != null) {
      setState(() {
        // _image = File(pickedFile.path);
      });
      // print("object  nldxl  ${_image}");
      // Replace the following line with your actual image picking logic.
      // _originalImage = await ImagePicker().pickImage(source: ImageSource.gallery);

      // For demonstration purposes, we'll use a placeholder image.
      _originalImage = File('${pickedFile.path}');
      setState(() {});

    }

  }

  Future<void> _compressImage() async {
    if (_originalImage == null) {
      return;
    }

    try {
      final Uint8List originalBytes = await _originalImage!.readAsBytes();
      final List<int> compressedBytes = await FlutterImageCompress.compressWithList(
        originalBytes,
        quality: _quality,
        format: CompressFormat.jpeg,
      );
      Directory directory = await getApplicationDocumentsDirectory();
      String compressedImagePath = '${directory.path}/OriginalImage.jpg';

      // final String compressedImagePath = '/path/to/your/compressed_image.jpg';

      // Save the compressed image.
      await File(compressedImagePath).writeAsBytes(compressedBytes);

      setState(() {
        _compressedImage = File(compressedImagePath);
      });
    } catch (e) {
      print('Error compressing image: $e');
    }
  }
}*/
